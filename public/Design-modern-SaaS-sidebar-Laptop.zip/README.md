
  # Design modern SaaS sidebar

  This is a code bundle for Design modern SaaS sidebar. The original project is available at https://www.figma.com/design/lgg39tDwwmwhgxi4R0QI5l/Design-modern-SaaS-sidebar.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  