import { useState } from 'react';
import { motion } from 'motion/react';
import {
  LayoutDashboard,
  BookOpen,
  CheckSquare,
  BarChart3,
  Palette,
  Brain,
  Crown,
  LogOut,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from './ui/tooltip';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const mainNavItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'study', label: 'Study', icon: BookOpen },
  { id: 'tasks', label: 'Tasks', icon: CheckSquare },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
];

const secondaryNavItems: NavItem[] = [
  { id: 'personalization', label: 'Personalization', icon: Palette },
  { id: 'ai-control', label: 'AI Control', icon: Brain },
];

export function Sidebar() {
  const [isExpanded, setIsExpanded] = useState(true);
  const [activeItem, setActiveItem] = useState('dashboard');

  const toggleSidebar = () => {
    setIsExpanded(!isExpanded);
  };

  const renderNavItem = (item: NavItem) => {
    const isActive = activeItem === item.id;
    const Icon = item.icon;

    const button = (
      <motion.button
        onClick={() => setActiveItem(item.id)}
        className={`
          w-full flex items-center gap-3 px-3 py-2.5 rounded-[10px] transition-colors
          ${isActive 
            ? 'bg-violet-500/12 border border-violet-500/40' 
            : 'bg-transparent border border-transparent hover:bg-white/5'
          }
        `}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
      >
        <Icon className="w-5 h-5 text-white/90 flex-shrink-0" />
        <motion.span
          className="text-sm text-white/90 whitespace-nowrap"
          initial={false}
          animate={{
            opacity: isExpanded ? 1 : 0,
            width: isExpanded ? 'auto' : 0,
          }}
          transition={{ duration: 0.2 }}
          style={{ overflow: 'hidden' }}
        >
          {item.label}
        </motion.span>
      </motion.button>
    );

    if (!isExpanded) {
      return (
        <Tooltip key={item.id} delayDuration={0}>
          <TooltipTrigger asChild>{button}</TooltipTrigger>
          <TooltipContent side="right" className="bg-zinc-900 border-zinc-800">
            <p>{item.label}</p>
          </TooltipContent>
        </Tooltip>
      );
    }

    return <div key={item.id}>{button}</div>;
  };

  return (
    <TooltipProvider>
      <motion.aside
        initial={false}
        animate={{ width: isExpanded ? 240 : 72 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="h-screen flex flex-col relative"
        style={{
          background: 'linear-gradient(180deg, #0a0a0c 0%, #050507 100%)',
        }}
      >
        {/* Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="absolute -right-3 top-8 w-6 h-6 bg-zinc-800 hover:bg-zinc-700 rounded-full flex items-center justify-center border border-zinc-700 transition-colors z-10"
        >
          {isExpanded ? (
            <ChevronLeft className="w-4 h-4 text-white/70" />
          ) : (
            <ChevronRight className="w-4 h-4 text-white/70" />
          )}
        </button>

        {/* Header */}
        <div className="p-4 pb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <motion.h1
              className="text-white/90 font-semibold text-base whitespace-nowrap"
              initial={false}
              animate={{
                opacity: isExpanded ? 1 : 0,
                width: isExpanded ? 'auto' : 0,
              }}
              transition={{ duration: 0.2 }}
              style={{ overflow: 'hidden' }}
            >
              Study Command
            </motion.h1>
          </div>
        </div>

        {/* Main Navigation */}
        <div className="px-3 flex-1">
          <div className="flex flex-col gap-1.5">
            {mainNavItems.map(renderNavItem)}
          </div>

          {/* Secondary Navigation */}
          <div className="mt-6 flex flex-col gap-1.5">
            {secondaryNavItems.map(renderNavItem)}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 space-y-2 border-t border-white/5">
          {/* Premium Button */}
          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <motion.button
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[10px] bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 transition-all"
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
              >
                <Crown className="w-5 h-5 text-white flex-shrink-0" />
                <motion.span
                  className="text-sm text-white font-medium whitespace-nowrap"
                  initial={false}
                  animate={{
                    opacity: isExpanded ? 1 : 0,
                    width: isExpanded ? 'auto' : 0,
                  }}
                  transition={{ duration: 0.2 }}
                  style={{ overflow: 'hidden' }}
                >
                  Upgrade Premium
                </motion.span>
              </motion.button>
            </TooltipTrigger>
            {!isExpanded && (
              <TooltipContent side="right" className="bg-zinc-900 border-zinc-800">
                <p>Upgrade Premium</p>
              </TooltipContent>
            )}
          </Tooltip>

          {/* User Email */}
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="px-3 py-2"
            >
              <p className="text-xs text-white/50 truncate">user@example.com</p>
            </motion.div>
          )}

          {/* Logout */}
          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <motion.button
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[10px] bg-transparent border border-transparent hover:bg-white/5 transition-colors"
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
              >
                <LogOut className="w-5 h-5 text-white/70 flex-shrink-0" />
                <motion.span
                  className="text-sm text-white/70 whitespace-nowrap"
                  initial={false}
                  animate={{
                    opacity: isExpanded ? 1 : 0,
                    width: isExpanded ? 'auto' : 0,
                  }}
                  transition={{ duration: 0.2 }}
                  style={{ overflow: 'hidden' }}
                >
                  Logout
                </motion.span>
              </motion.button>
            </TooltipTrigger>
            {!isExpanded && (
              <TooltipContent side="right" className="bg-zinc-900 border-zinc-800">
                <p>Logout</p>
              </TooltipContent>
            )}
          </Tooltip>
        </div>
      </motion.aside>
    </TooltipProvider>
  );
}
