import { Sidebar } from './components/Sidebar';

export default function App() {
  return (
    <div className="flex h-screen bg-zinc-950">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="p-8">
          <h1 className="text-3xl font-semibold text-white/90 mb-2">
            Welcome to Study Command
          </h1>
          <p className="text-white/60">
            Your modern study companion with a clean, minimal interface.
          </p>
          
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div
                key={i}
                className="p-6 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
              >
                <h3 className="text-lg font-medium text-white/90 mb-2">
                  Feature Card {i}
                </h3>
                <p className="text-sm text-white/60">
                  Click items in the sidebar to navigate between different sections.
                </p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
