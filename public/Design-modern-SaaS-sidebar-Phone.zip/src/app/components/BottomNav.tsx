import { useLocation, useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Home, BookOpen, Flame, ListTodo, Settings } from "lucide-react";

const navItems = [
  { path: "/", label: "Home", icon: Home },
  { path: "/study", label: "Study", icon: BookOpen },
  { path: "/tasks", label: "Tasks", icon: Flame },
  { path: "/analytics", label: "Analytics", icon: ListTodo },
  { path: "/settings", label: "Settings", icon: Settings },
];

export function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();

  const activeIndex = navItems.findIndex((item) => item.path === location.pathname);

  return (
    <div className="fixed bottom-0 left-0 right-0 flex justify-center pb-8 px-6 pointer-events-none">
      <div className="relative w-full max-w-md pointer-events-auto">
        {/* Dynamic SVG with notch at active position */}
        <motion.svg
          className="absolute inset-0 w-full h-20"
          viewBox="0 0 500 80"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
          key={activeIndex}
        >
          <motion.path
            d={generateNavPath(activeIndex)}
            fill="#000000"
            stroke="rgba(168, 85, 247, 0.4)"
            strokeWidth="1.5"
            initial={{ d: generateNavPath(activeIndex) }}
            animate={{ d: generateNavPath(activeIndex) }}
            transition={{ type: "spring", stiffness: 200, damping: 25 }}
          />
        </motion.svg>

        {/* Navigation Items */}
        <div className="relative flex items-center justify-around h-20">
          {navItems.map((item, index) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;

            return (
              <motion.button
                key={item.path}
                onClick={() => navigate(item.path)}
                className="relative flex items-center justify-center p-4"
                animate={{
                  y: isActive ? -24 : 0,
                }}
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
                whileTap={{ scale: 0.9 }}
              >
                <motion.div
                  animate={{
                    scale: isActive ? 1.3 : 1,
                  }}
                  transition={{ type: "spring", stiffness: 300, damping: 25 }}
                >
                  <Icon 
                    className={`w-6 h-6 ${isActive ? "text-orange-500" : "text-white"}`}
                    strokeWidth={2.5}
                  />
                </motion.div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// Generate SVG path with notch at the active position
function generateNavPath(activeIndex: number): string {
  const totalItems = 5;
  const segmentWidth = 500 / totalItems;
  const notchCenter = (activeIndex + 0.5) * segmentWidth;
  const notchWidth = 80;
  const notchDepth = 35;
  
  const notchStart = notchCenter - notchWidth / 2;
  const notchEnd = notchCenter + notchWidth / 2;
  
  return `
    M 40 10
    L ${notchStart - 20} 10
    Q ${notchStart - 10} 10 ${notchStart - 5} 12
    Q ${notchCenter - 25} ${notchDepth} ${notchCenter} ${notchDepth}
    Q ${notchCenter + 25} ${notchDepth} ${notchEnd + 5} 12
    Q ${notchEnd + 10} 10 ${notchEnd + 20} 10
    L 460 10
    Q 480 10 480 30
    L 480 50
    Q 480 70 460 70
    L 40 70
    Q 20 70 20 50
    L 20 30
    Q 20 10 40 10 Z
  `;
}