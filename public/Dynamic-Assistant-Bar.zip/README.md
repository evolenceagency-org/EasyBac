
  # Dynamic Assistant Bar

  This is a code bundle for Dynamic Assistant Bar. The original project is available at https://www.figma.com/design/m0ofAfc8gMPsOZIhd098VS/Dynamic-Assistant-Bar.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  