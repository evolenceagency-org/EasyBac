import { DynamicIsland } from './components/DynamicIsland';

export default function App() {
  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <DynamicIsland />
      
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
      </div>

      {/* Info text */}
      <div className="absolute bottom-8 text-center text-white/40 text-sm">
        <p>Dynamic Island Demo</p>
        <p className="text-xs mt-1">Automatically cycles through different states</p>
      </div>
    </div>
  );
}