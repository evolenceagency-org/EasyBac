import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'motion/react';
import { Play, Pause, SkipForward, SkipBack, Phone, PhoneOff, Timer, Bell, Mic, Volume2, Sparkles, Check, X } from 'lucide-react';

type IslandState = 'compact' | 'music' | 'call' | 'timer' | 'notification' | 'ai';

interface MusicData {
  title: string;
  artist: string;
  isPlaying: boolean;
}

interface CallData {
  caller: string;
  duration: number;
}

interface TimerData {
  remaining: number;
}

interface NotificationData {
  title: string;
  message: string;
}

export function DynamicIsland() {
  const [state, setState] = useState<IslandState>('call');
  const [isHolding, setIsHolding] = useState(false);
  const [holdProgress, setHoldProgress] = useState(0);
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);
  const [verticalSwipeDirection, setVerticalSwipeDirection] = useState<'up' | 'down' | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  
  const dragX = useMotionValue(0);
  const dragY = useMotionValue(0);
  
  // Limit horizontal drag to max 50px for subtle feedback
  const limitedDragX = useTransform(dragX, (value) => {
    const max = 50;
    if (value > max) return max;
    if (value < -max) return -max;
    return value;
  });
  
  const opacity = useTransform(limitedDragX, [-50, 0, 50], [0.9, 1, 0.9]);
  
  // Transform values for swipe indicators
  const rightIndicatorOpacity = useTransform(dragX, [0, 80], [0.3, 1]);
  const rightIndicatorScale = useTransform(dragX, [0, 80], [0.8, 1.2]);
  const leftIndicatorOpacity = useTransform(dragX, [-80, 0], [1, 0.3]);
  const leftIndicatorScale = useTransform(dragX, [-80, 0], [1.2, 0.8]);
  
  const holdTimerRef = useRef<NodeJS.Timeout | null>(null);
  const holdProgressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  
  const [musicData, setMusicData] = useState<MusicData>({
    title: 'Midnight City',
    artist: 'M83',
    isPlaying: false,
  });
  const [callData, setCallData] = useState<CallData>({
    caller: 'John Doe',
    duration: 0,
  });
  const [timerData, setTimerData] = useState<TimerData>({
    remaining: 180,
  });
  const [notificationData] = useState<NotificationData>({
    title: 'New Message',
    message: 'Hey! How are you doing?',
  });

  useEffect(() => {
    if (state === 'call') {
      const interval = setInterval(() => {
        setCallData(prev => ({ ...prev, duration: prev.duration + 1 }));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [state]);

  useEffect(() => {
    if (state === 'timer' && timerData.remaining > 0) {
      const interval = setInterval(() => {
        setTimerData(prev => ({ remaining: Math.max(0, prev.remaining - 1) }));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [state, timerData.remaining]);

  useEffect(() => {
    if (actionFeedback) {
      const timeout = setTimeout(() => setActionFeedback(''), 2000);
      return () => clearTimeout(timeout);
    }
  }, [actionFeedback]);

  useEffect(() => {
    if (isHolding && holdProgress >= 100) {
      setState('ai');
      setActionFeedback('AI Assistant Activated');
      setIsHolding(false);
      setHoldProgress(0);
    }
  }, [isHolding, holdProgress]);

  useEffect(() => {
    if (!swipeDirection) return;

    if (swipeDirection === 'right') {
      if (state === 'call') {
        setActionFeedback('✓ Call Accepted');
      } else if (state === 'notification') {
        setActionFeedback('✓ Action Confirmed');
      } else {
        setActionFeedback('✓ Accepted');
      }
    } else if (swipeDirection === 'left') {
      if (state === 'call') {
        setActionFeedback('✗ Call Declined');
        setTimeout(() => setState('compact'), 500);
      } else if (state === 'notification') {
        setActionFeedback('✗ Dismissed');
        setTimeout(() => setState('compact'), 500);
      } else {
        setActionFeedback('✗ Cancelled');
      }
    }

    setTimeout(() => setSwipeDirection(null), 800);
  }, [swipeDirection, state]);

  useEffect(() => {
    if (!verticalSwipeDirection) return;

    if (verticalSwipeDirection === 'up') {
      cycleStates('up');
    } else if (verticalSwipeDirection === 'down') {
      cycleStates('down');
    }

    setTimeout(() => setVerticalSwipeDirection(null), 400);
  }, [verticalSwipeDirection]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getIslandWidth = () => {
    if (isHolding || state === 'ai') return 280;
    
    switch (state) {
      case 'music':
        return 360;
      case 'call':
        return 280;
      case 'timer':
        return 240;
      case 'notification':
        return 340;
      default:
        return 150;
    }
  };

  const getIslandHeight = () => {
    if (isHolding || state === 'ai') return 80;
    
    switch (state) {
      case 'music':
        return 80;
      case 'call':
        return 70;
      case 'timer':
        return 70;
      case 'notification':
        return 80;
      default:
        return 37;
    }
  };

  const cycleStates = (direction: 'up' | 'down') => {
    const states: IslandState[] = ['compact', 'music', 'call', 'timer', 'notification'];
    const currentIndex = states.indexOf(state);
    
    if (direction === 'up') {
      const nextIndex = (currentIndex + 1) % states.length;
      setState(states[nextIndex]);
    } else {
      const prevIndex = (currentIndex - 1 + states.length) % states.length;
      setState(states[prevIndex]);
    }
  };

  const startHoldProgress = () => {
    setHoldProgress(0);
    holdProgressIntervalRef.current = setInterval(() => {
      setHoldProgress(prev => {
        if (prev >= 100) {
          if (holdProgressIntervalRef.current) {
            clearInterval(holdProgressIntervalRef.current);
          }
          return 100;
        }
        return prev + 2;
      });
    }, 14);
  };

  const stopHoldProgress = () => {
    if (holdProgressIntervalRef.current) {
      clearInterval(holdProgressIntervalRef.current);
      holdProgressIntervalRef.current = null;
    }
    setHoldProgress(0);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY, time: Date.now() };
    setIsDragging(true);
    
    holdTimerRef.current = setTimeout(() => {
      setIsHolding(true);
      startHoldProgress();
    }, 200);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartRef.current) return;
    
    const touch = e.touches[0];
    const { x: startX, y: startY } = touchStartRef.current;
    const deltaX = touch.clientX - startX;
    const deltaY = touch.clientY - startY;
    
    dragX.set(deltaX);
    dragY.set(deltaY);
    
    if (Math.abs(deltaX) > 15 || Math.abs(deltaY) > 15) {
      if (holdTimerRef.current) {
        clearTimeout(holdTimerRef.current);
        holdTimerRef.current = null;
      }
      if (isHolding) {
        setIsHolding(false);
        stopHoldProgress();
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    
    setIsDragging(false);
    
    if (isHolding) {
      stopHoldProgress();
      setIsHolding(false);
      dragX.set(0);
      dragY.set(0);
      return;
    }
    
    if (!touchStartRef.current) return;
    
    const touch = e.changedTouches[0];
    const { x: startX, y: startY, time: startTime } = touchStartRef.current;
    const deltaX = touch.clientX - startX;
    const deltaY = touch.clientY - startY;
    const deltaTime = Date.now() - startTime;

    // Reset drag values
    dragX.set(0);
    dragY.set(0);

    if (deltaTime < 500) {
      if (Math.abs(deltaX) > 80 && Math.abs(deltaX) > Math.abs(deltaY)) {
        const direction = deltaX > 0 ? 'right' : 'left';
        setSwipeDirection(direction);
      }
      else if (Math.abs(deltaY) > 80 && Math.abs(deltaY) > Math.abs(deltaX)) {
        const direction = deltaY < 0 ? 'up' : 'down';
        setVerticalSwipeDirection(direction);
      }
      else if (Math.abs(deltaX) < 10 && Math.abs(deltaY) < 10) {
        if (state === 'compact') {
          setState('call');
        }
      }
    }

    touchStartRef.current = null;
  };

  const handleTouchCancel = () => {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    stopHoldProgress();
    touchStartRef.current = null;
    setIsHolding(false);
    setIsDragging(false);
    dragX.set(0);
    dragY.set(0);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    const startX = e.clientX;
    const startY = e.clientY;
    const startTime = Date.now();
    setIsDragging(true);
    
    holdTimerRef.current = setTimeout(() => {
      setIsHolding(true);
      startHoldProgress();
    }, 200);

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const deltaY = moveEvent.clientY - startY;
      
      dragX.set(deltaX);
      dragY.set(deltaY);
      
      if (Math.abs(deltaX) > 15 || Math.abs(deltaY) > 15) {
        if (holdTimerRef.current) {
          clearTimeout(holdTimerRef.current);
          holdTimerRef.current = null;
        }
        if (isHolding) {
          setIsHolding(false);
          stopHoldProgress();
        }
      }
    };

    const handleMouseUp = (upEvent: MouseEvent) => {
      if (holdTimerRef.current) {
        clearTimeout(holdTimerRef.current);
        holdTimerRef.current = null;
      }

      setIsDragging(false);

      if (isHolding) {
        setIsHolding(false);
        stopHoldProgress();
        dragX.set(0);
        dragY.set(0);
      } else {
        const deltaX = upEvent.clientX - startX;
        const deltaY = upEvent.clientY - startY;
        const deltaTime = Date.now() - startTime;

        // Reset drag values
        dragX.set(0);
        dragY.set(0);

        if (deltaTime < 500) {
          if (Math.abs(deltaX) > 80 && Math.abs(deltaX) > Math.abs(deltaY)) {
            const direction = deltaX > 0 ? 'right' : 'left';
            setSwipeDirection(direction);
          } else if (Math.abs(deltaY) > 80 && Math.abs(deltaY) > Math.abs(deltaX)) {
            const direction = deltaY < 0 ? 'up' : 'down';
            setVerticalSwipeDirection(direction);
          } else if (Math.abs(deltaX) < 10 && Math.abs(deltaY) < 10) {
            if (state === 'compact') {
              setState('call');
            }
          }
        }
      }

      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50">
      <motion.div
        layout
        style={{
          x: limitedDragX,
          opacity,
        }}
        animate={{
          width: getIslandWidth(),
          height: getIslandHeight(),
          scale: isHolding ? 1.05 + (holdProgress / 400) : 1,
        }}
        transition={{
          type: 'spring',
          stiffness: 400,
          damping: 30,
          x: { type: 'spring', stiffness: 300, damping: 25 },
        }}
        className="relative bg-black rounded-[30px] shadow-2xl overflow-visible cursor-pointer select-none"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchCancel}
        onMouseDown={handleMouseDown}
      >
        {/* Hold progress ring */}
        <AnimatePresence>
          {isHolding && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute -inset-2 pointer-events-none"
            >
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="48"
                  fill="none"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="2"
                />
                <motion.circle
                  cx="50"
                  cy="50"
                  r="48"
                  fill="none"
                  stroke="url(#gradient)"
                  strokeWidth="2"
                  strokeLinecap="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: holdProgress / 100 }}
                  transition={{ duration: 0.1 }}
                  style={{
                    pathLength: holdProgress / 100,
                    strokeDasharray: '0 1',
                  }}
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#667eea" />
                    <stop offset="50%" stopColor="#f093fb" />
                    <stop offset="100%" stopColor="#4facfe" />
                  </linearGradient>
                </defs>
              </svg>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Swipe indicators with distance-based visibility */}
        <AnimatePresence>
          {(state === 'call' || state === 'notification') && !isHolding && (
            <>
              <motion.div
                style={{
                  opacity: rightIndicatorOpacity,
                  scale: rightIndicatorScale,
                }}
                className="absolute -right-14 top-1/2 -translate-y-1/2 pointer-events-none"
              >
                <motion.div
                  animate={{
                    scale: swipeDirection === 'right' ? [1, 1.3, 1] : 1,
                    rotate: swipeDirection === 'right' ? [0, 10, 0] : 0,
                  }}
                  transition={{ duration: 0.4 }}
                  className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center shadow-lg shadow-green-500/50"
                >
                  <Check className="w-6 h-6 text-white" />
                </motion.div>
              </motion.div>
              <motion.div
                style={{
                  opacity: leftIndicatorOpacity,
                  scale: leftIndicatorScale,
                }}
                className="absolute -left-14 top-1/2 -translate-y-1/2 pointer-events-none"
              >
                <motion.div
                  animate={{
                    scale: swipeDirection === 'left' ? [1, 1.3, 1] : 1,
                    rotate: swipeDirection === 'left' ? [0, -10, 0] : 0,
                  }}
                  transition={{ duration: 0.4 }}
                  className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center shadow-lg shadow-red-500/50"
                >
                  <X className="w-6 h-6 text-white" />
                </motion.div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Main content container */}
        <div className="absolute inset-0 rounded-[30px] overflow-hidden">
          {/* Compact State */}
          <AnimatePresence mode="wait">
            {state === 'compact' && !isHolding && (
              <motion.div
                key="compact"
                initial={{ opacity: 0, y: verticalSwipeDirection === 'up' ? 30 : verticalSwipeDirection === 'down' ? -30 : 0 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: verticalSwipeDirection === 'up' ? -30 : verticalSwipeDirection === 'down' ? 30 : 0 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <motion.div
                  animate={{
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                  className="flex gap-2"
                >
                  <div className="w-2 h-2 bg-purple-500 rounded-full" />
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Music Player State */}
          <AnimatePresence mode="wait">
            {state === 'music' && !isHolding && (
              <motion.div
                key="music"
                initial={{ opacity: 0, y: verticalSwipeDirection === 'up' ? 30 : verticalSwipeDirection === 'down' ? -30 : 0 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: verticalSwipeDirection === 'up' ? -30 : verticalSwipeDirection === 'down' ? 30 : 0 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="absolute inset-0 flex items-center gap-4 px-5"
              >
                <motion.div
                  initial={{ rotate: 0 }}
                  animate={{ rotate: musicData.isPlaying ? 360 : 0 }}
                  transition={{
                    duration: 3,
                    repeat: musicData.isPlaying ? Infinity : 0,
                    ease: 'linear',
                  }}
                  className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0"
                >
                  <Volume2 className="w-6 h-6 text-white" />
                </motion.div>

                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-semibold truncate">
                    {musicData.title}
                  </div>
                  <div className="text-gray-400 text-xs truncate">
                    {musicData.artist}
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    <SkipBack className="w-4 h-4" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      setMusicData(prev => ({ ...prev, isPlaying: !prev.isPlaying }));
                    }}
                    className="text-white"
                  >
                    {musicData.isPlaying ? (
                      <Pause className="w-5 h-5 fill-white" />
                    ) : (
                      <Play className="w-5 h-5 fill-white" />
                    )}
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    <SkipForward className="w-4 h-4" />
                  </motion.button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Call State */}
          <AnimatePresence mode="wait">
            {state === 'call' && !isHolding && (
              <motion.div
                key="call"
                initial={{ opacity: 0, y: verticalSwipeDirection === 'up' ? 30 : verticalSwipeDirection === 'down' ? -30 : 0 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: verticalSwipeDirection === 'up' ? -30 : verticalSwipeDirection === 'down' ? 30 : 0 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="absolute inset-0 flex items-center justify-between px-5"
              >
                <div className="flex items-center gap-3">
                  <motion.div
                    animate={{
                      scale: [1, 1.1, 1],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                    }}
                    className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0"
                  >
                    <Phone className="w-5 h-5 text-white" />
                  </motion.div>
                  <div>
                    <div className="text-white text-sm font-semibold">{callData.caller}</div>
                    <div className="text-gray-400 text-xs">{formatTime(callData.duration)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                    className="w-1.5 h-1.5 bg-green-400 rounded-full"
                  />
                  <Mic className="w-4 h-4 text-gray-400" />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Timer State */}
          <AnimatePresence mode="wait">
            {state === 'timer' && !isHolding && (
              <motion.div
                key="timer"
                initial={{ opacity: 0, y: verticalSwipeDirection === 'up' ? 30 : verticalSwipeDirection === 'down' ? -30 : 0 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: verticalSwipeDirection === 'up' ? -30 : verticalSwipeDirection === 'down' ? 30 : 0 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="absolute inset-0 flex items-center gap-4 px-5"
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: 'linear',
                  }}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center flex-shrink-0"
                >
                  <Timer className="w-5 h-5 text-white" />
                </motion.div>
                <div>
                  <div className="text-gray-400 text-xs">Timer</div>
                  <motion.div
                    key={timerData.remaining}
                    initial={{ scale: 1.2 }}
                    animate={{ scale: 1 }}
                    className="text-white text-xl font-bold tabular-nums"
                  >
                    {formatTime(timerData.remaining)}
                  </motion.div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Notification State */}
          <AnimatePresence mode="wait">
            {state === 'notification' && !isHolding && (
              <motion.div
                key="notification"
                initial={{ opacity: 0, y: verticalSwipeDirection === 'up' ? 30 : verticalSwipeDirection === 'down' ? -30 : 0 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: verticalSwipeDirection === 'up' ? -30 : verticalSwipeDirection === 'down' ? 30 : 0 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="absolute inset-0 flex items-center gap-3 px-5"
              >
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0"
                >
                  <Bell className="w-5 h-5 text-white" />
                </motion.div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-semibold">
                    {notificationData.title}
                  </div>
                  <div className="text-gray-400 text-xs truncate">
                    {notificationData.message}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* AI State */}
          <AnimatePresence mode="wait">
            {(state === 'ai' || isHolding) && (
              <motion.div
                key="ai"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.3 }}
                className="absolute inset-0 flex items-center gap-4 px-5"
              >
                <motion.div
                  animate={{
                    rotate: 360,
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    rotate: { duration: 3, repeat: Infinity, ease: 'linear' },
                    scale: { duration: 1.5, repeat: Infinity, ease: 'easeInOut' },
                  }}
                  className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 relative"
                >
                  <motion.div
                    animate={{
                      background: [
                        'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                        'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
                        'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
                        'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
                        'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      ],
                    }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                    className="absolute inset-0 rounded-full"
                  />
                  <Sparkles className="w-6 h-6 text-white relative z-10" />
                </motion.div>
                <div className="flex-1">
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                    className="text-white text-sm font-semibold"
                  >
                    AI Assistant
                  </motion.div>
                  <motion.div
                    className="text-transparent bg-clip-text text-xs"
                    animate={{
                      backgroundImage: [
                        'linear-gradient(90deg, #667eea, #764ba2)',
                        'linear-gradient(90deg, #f093fb, #f5576c)',
                        'linear-gradient(90deg, #4facfe, #00f2fe)',
                        'linear-gradient(90deg, #667eea, #764ba2)',
                      ],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                    }}
                  >
                    {isHolding ? `${Math.round(holdProgress)}%` : 'Listening...'}
                  </motion.div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Animated glow effect */}
        <motion.div
          className="absolute inset-0 rounded-[30px] opacity-20 pointer-events-none"
          animate={{
            background: isHolding || state === 'ai'
              ? [
                  'radial-gradient(circle at 50% 50%, rgba(102, 126, 234, 0.6), transparent)',
                  'radial-gradient(circle at 50% 50%, rgba(240, 147, 251, 0.6), transparent)',
                  'radial-gradient(circle at 50% 50%, rgba(79, 172, 254, 0.6), transparent)',
                  'radial-gradient(circle at 50% 50%, rgba(67, 233, 123, 0.6), transparent)',
                  'radial-gradient(circle at 50% 50%, rgba(102, 126, 234, 0.6), transparent)',
                ]
              : [
                  'radial-gradient(circle at 50% 50%, rgba(168, 85, 247, 0.4), transparent)',
                  'radial-gradient(circle at 50% 50%, rgba(59, 130, 246, 0.4), transparent)',
                  'radial-gradient(circle at 50% 50%, rgba(168, 85, 247, 0.4), transparent)',
                ],
          }}
          transition={{
            duration: isHolding || state === 'ai' ? 4 : 3,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      </motion.div>

      {/* Gesture hints */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute -bottom-16 left-1/2 -translate-x-1/2 text-center text-white/50 text-xs whitespace-nowrap space-y-1"
      >
        <div className="flex items-center gap-4 justify-center">
          <span>↕️ Swipe Up/Down: Switch</span>
          <span>↔️ Swipe L/R: Accept/Refuse</span>
          <span>🖱️ Hold: AI</span>
        </div>
        {state === 'compact' && <div className="text-white/40">Tap to start</div>}
      </motion.div>

      {/* Action Feedback */}
      <AnimatePresence>
        {actionFeedback && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.8 }}
            className="absolute -bottom-28 left-1/2 -translate-x-1/2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm font-medium whitespace-nowrap"
          >
            {actionFeedback}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
